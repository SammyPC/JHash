#include<iostream>

using namespace std;

int main() {
    for(int i = 33; i < 127; i++) {
        cout << (char)i << " = " << i << endl;
    }
}